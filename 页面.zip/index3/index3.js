// pages/index3/index3.js
// 搜索
Page({
  /**
   * 页面的初始数据,可以为空
   */
  data: {

  },
  // 查询搜索的接口方法
  a: function () {

  }
})