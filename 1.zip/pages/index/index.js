// pages/index/index.js
var province = require('../../libs/province.js');
var bmap = require('../../libs/bmap-wx.js');


//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    province: '',
    city: '',
    markers: [],
    latitude: '',
    longitude: '',
    scale: 14
  },
  //给全国各省在地图做标记点
  markerprovince: function () {
    var map = new province.Province();
    var markers = map.markers;
    this.setData({
      markers: markers,
      scale: 4
    })
  },
  //我的位置
  getmylocation() {
    var that = this;
    var markers = [];
    var marker = {};
    wx.getLocation({
      success: function (res) {
        latitude = res.latitude;
        longitude = res.longitude;
      },
      success(res) {
        marker.alpha = 1;
        marker.iconPath = "../../img/marker_red.png";
        marker.id = 0;
        marker.longitude = res.longitude;
        marker.latitude = res.latitude;
        marker.title = "我的位置";
        markers[0] = marker;
        that.getName(res.latitude, res.longitude);
        that.setData({
          longitude: res.longitude,
          latitude: res.latitude,
          markers: markers,
          scale: 14
        })
      }
    })
  },

  //根据经纬度获取城市名，省名
  getName: function (lat, lon) {
    var that = this;
    var city = '';
    var province = '';
    wx.request({
      url: 'https://api.map.baidu.com/reverse_geocoding/v3/?',
      data: {
        ak: 'qnYCjCB1I3MNOK9pG7zHcLESAnfHXhar',
        output: 'json',
        coordtype: 'wgs8411',
        location: lat + "," + lon
      },
      success(res) {
        res = res.data.result.addressComponent;
        city = res.city;
        province = res.province;
        that.setData({
          province: province,
          city: city
        })
      }
    })
  },


  onLoad: function () {
    this.getmylocation();
  },
})
