// pages/index/index.js
var province = require('../../libs/province.js');
//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    province: '',
    city: '',
    markers: [],
    latitude: '',
    longitude: '',
    scale: 14,

    multiIndex: [29, 25],
    multiArray: [[], []],
    multiprovince: "广东",
    multitem: '25',
    multicitys: [],
  },

  setmultiArray: function () {
    var allprovince = new province.Province();
    var that = this;
    var mul = "multiArray[0]";
    var tem = "multiArray[1]";
    var address = [];
    var temp = [];
    var citys = [];
    wx.request({
      url: 'https://restapi.amap.com/v3/config/district?',
      data: {
        key: '0ea0022435db7b533d8cb3db5a153afa',
        keywords: "广东",
      },
      success(res) {
        citys = res.data.districts[0].districts;
        that.setData({
          multicitys: citys
        })
      }
    })
    for (var j = 0; j <= 25; j++) {
      temp[j] = j;
      this.setData({
        [tem]: temp
      })
    }
    for (var i = 0; i < allprovince.markers.length; i++) {
      address[i] = allprovince.markers[i].address;
      this.setData({
        array: address,
        [mul]: address
      })
    }
  },

  bindMultiPickerColumnChange: function (e) {
    var that = this;
    if (e.detail.column === 0) {
      var searchprovince = that.data.multiArray[0][e.detail.value];
      wx.request({
        url: 'https://restapi.amap.com/v3/config/district?',
        data: {
          key: '0ea0022435db7b533d8cb3db5a153afa',
          keywords: searchprovince,
        },
        success(res) {
          var center = res.data.districts[0].center;
          center = center.split(",");
          var districts = res.data.districts[0].districts;
          that.setData({
            multicitys: districts,
            multiprovince: searchprovince,
            latitude: center[1],
            longitude: center[0]
          })
        }
      })
    }
    else if (e.detail.column === 1) {
      var temp = that.data.multiArray[1][e.detail.value];
      that.setData({
        multitem: temp
      })
    }
  },

  bindMultiPickerChange: function (e) {
    var that = this;
    var length = that.data.multicitys.length;
    var districts = that.data.multicitys;
    var tem = that.data.multitem;
    var markers = [];
    var number = 0;
    that.setData({
      markers: []
    })
    for (var i = 0; i < length; i++) {
      wx.request({
        url: 'https://restapi.amap.com/v3/weather/weatherInfo?',
        data: {
          city: districts[i].adcode,
          extensions: 'base',
          key: '0ea0022435db7b533d8cb3db5a153afa'
        },
        success(res) {
          var marker = {};
          var lives = res.data.lives[0];
          if (lives.temperature > tem) {
            for (var j = 0; j < districts.length; j++) {
              if (lives.city == districts[j].name) {
                var center = districts[j].center;
                var setmarkers = "markers[" + number + "]";
                center = center.split(",");
                marker.address = lives.city;
                marker.alpha = 1;
                marker.iconPath = "../../img/marker_red.png";
                marker.latitude = center[1];
                marker.longitude = center[0];
                marker.title = lives.city + lives.temperature + "℃";
                markers[number] = marker;
                that.setData({
                  [setmarkers]: marker,
                  scale: 7
                })
                number++;
              }
            }
          }
        }
      })
    }
  },

  onLoad: function () {
    this.setmultiArray();
  },

  
})
