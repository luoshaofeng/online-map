// pages/new/new.js
var bmap = require('../../libs/bmap-wx.js');
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    longitude: '113.758418',  //经度
    latitude: '23.027308',   //纬度
    location: '东莞市',    //位置
    now: {},               //今日天气
    air_now_city: {},    //当前城市空气质量
    daily_forecast: '',    //近三天天气情况
    lifestyle: '',       //生活指数
  },


  //获取当前天气
  getWeather: function (res) {
    var that = this;
    var weather = {};
    wx.request({
      url: 'https://free-api.heweather.net/s6/weather/now?',
      data: {
        location: res[2],
        key: 'ee4d6c860dd44db187eb9193fba2227a'
      },
      success(res) {
        res = res.data.HeWeather6[0].now;
        that.setData({
          now: res
        })
      }
    }),
      wx.request({
        url: 'https://free-api.heweather.net/s6/air/now?',
        data: {
          location: res[2],
          key: 'ee4d6c860dd44db187eb9193fba2227a'
        },
        success(res) {
          res = res.data.HeWeather6[0].air_now_city;
          that.setData({
            air_now_city: res
          })
        }
      }),
      wx.request({
        url: 'https://free-api.heweather.net/s6/weather/forecast?',
        data: {
          location: res[2],
          key: 'ee4d6c860dd44db187eb9193fba2227a'
        },
        success(res) {
          res = res.data.HeWeather6[0].daily_forecast;
          that.setData({
            daily_forecast: res
          })
        }
      })
    wx.request({
      url: 'https://free-api.heweather.net/s6/weather/lifestyle?',
      data: {
        location: res[2],
        key: 'ee4d6c860dd44db187eb9193fba2227a'
      },
      success(res) {
        res = res.data.HeWeather6[0].lifestyle;
        that.setData({
          lifestyle: res
        })
      }
    })
    that.setData({
      location:res[0]+res[1]
    })
  },

  //获取当前位置
  getCityLocation: function () {
    var that = this;

    wx.getLocation({
      success: function (res) {
        var longitude = res.longitude;
        var latitude = res.latitude;
      },
      success(res) {
        that.setData({
          longitude: res.longitude,
          latitude: res.latitude
        })
      }
    })
  },

  //根据经纬度获取地点名称
  getplace: function () {
    var that = this;

    //获取获取地点名称
    var BMap = new bmap.BMapWX({
      ak: 'qnYCjCB1I3MNOK9pG7zHcLESAnfHXhar'
    });
    var success = function (res) {
      var location = res.originalData.result.addressComponent.city;
      that.setData({
        location: location
      })
    }
    BMap.regeocoding({
      success: success
    })
  },

  /**1
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    const eventChannel = this.getOpenerEventChannel();
    // eventChannel.emit('acceptDataFromOpenedPage', { data: 'test' });
    // eventChannel.emit('someEvent', { data: 'test' });
    // 监听acceptDataFromOpenerPage事件，获取上一页面通过eventChannel传送到当前页面的数据
    eventChannel.on('acceptDataFromOpenerPage', function (data) {
      that.getWeather(data);
    })

  },

  /**3
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  },

  /**2
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})