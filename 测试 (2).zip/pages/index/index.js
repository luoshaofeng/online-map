// pages/index/index.js
var province = require('../../libs/province.js');
var bmap = require('../../libs/bmap-wx.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    province:'',
    city:'',
    markers:[],
    latitude:'',
    longitude:'',
    scale:14,
    // province:'',
    // citys:[],
    // latitude: 23.13171,
    // longitude: 113.26627,
    // markers:[],
    // length:0,
    // tmp:[],
    // qlty:'',



    multiIndex: [29, 25],
    multiArray: [[], []],
    multiprovince:"广东",
    multitem:'25',
    multicitys:[],

    multiIndex1:[29,0],
    multiArray1:[[],[]],
    multicitys1:[],
    multiprovince1:"广东",
    multiair:"优",

    multiIndex2:[29,0],
    multiArray2:[[],[]],
    multiprovince2:"广东",
    centers:[],
    city2:"",
    center:'',

    index:29,
    array:[],





  },

  bindMultiPickerChange2:function(e)
  {
    if(this.data.multiArray2[1][e.detail.value[1]] == undefined)
    {
      var that = this;
      var setprovince = that.data.multiArray2[0][e.detail.value[0]];
      var setcity = that.data.multiArray2[1][e.detail.value[1]];
      var marker = {};
      var markers = [];
      var center = (that.data.center).split(",");
      marker.address = setprovince;
      marker.title = setprovince;
      marker.iconPath = "../../img/marker_red.png";
      marker.longitude = center[0];
      marker.latitude = center[1];
      markers[0] = marker; 
      that.setData({
        multiprovince2: setprovince,
        city2: '',
        markers:markers,
        latitude:center[1],
        longitude:center[0],
        scale:4
      })
    }
    else
    {
      var that = this;
      var setprovince = that.data.multiArray2[0][e.detail.value[0]];
      var setcity = that.data.multiArray2[1][e.detail.value[1]];
      var marker = {};
      var markers = [];
      var center = (that.data.center).split(",");
      marker.address = setprovince + setcity;
      marker.title = setprovince + setcity;
      marker.iconPath = "../../img/marker_red.png";
      marker.longitude = center[0];
      marker.latitude = center[1];
      markers[0] = marker; 
      that.setData({
        multiprovince2: setprovince,
        city2: setcity,
        markers:markers,
        latitude:center[1],
        longitude:center[0],
        scale:14
      })
    }
  },

  change:function(e)
  {
    var that = this;
    var searchprovince = this.data.multiArray2[0][e.detail.value];
    var mul1 = "multiArray2[1]";
    var address2 = [];
    var center2 = [];
    if(e.detail.column === 0)
    {
      wx.request({
        url: 'https://restapi.amap.com/v3/config/district?',
        data: {
          key: '0ea0022435db7b533d8cb3db5a153afa',
          keywords: searchprovince,
        },
        success(res) {
          if(res.data.districts[0].districts.length == 0)
          {
            var citys = res.data.districts[0].districts;
            for (var i = 0; i < citys.length; i++) {
              address2[i] = citys[i].name
            }
            that.setData({
              [mul1]: address2,
              center: res.data.districts[0].center
            })
          }
          else
          {
            var citys = res.data.districts[0].districts;
            for (var i = 0; i < citys.length; i++) {
              address2[i] = citys[i].name,
                center2[i] = citys[i].center
            }
            that.setData({
              [mul1]: address2,
              centers: center2,
              center:center2[0]
            })
          }
        }
      })
    }
    else if(e.detail.column === 1)
    {
      var center = this.data.centers[e.detail.value];
      this.setData({
        center:center
      })
    }
  },

  setmultiArray2:function(e)
  {
    var allprovince = new province.Province();
    var that = this;
    var mul = "multiArray2[0]";
    var mul1 = "multiArray2[1]";
    var address = [];
    var center2 = [];
    var address2 = [];
    var citys = [];
    wx.request({
      url: 'https://restapi.amap.com/v3/config/district?',
      data: {
        key: '0ea0022435db7b533d8cb3db5a153afa',
        keywords: "广东",
      },
      success(res) {
        citys = res.data.districts[0].districts;
        for(var i = 0; i < citys.length; i++)
        {
          address2[i] = citys[i].name;
          center2[i] = citys[i].center;
        }
        that.setData({
          [mul1]: address2,
          city2:citys[0].name,
          centers:center2,
          center:center2[0]
        })
      }
    })
    for (var i = 0; i < allprovince.markers.length; i++) {
      address[i] = allprovince.markers[i].address;
      this.setData({
        [mul]: address,
      })
    }
  },

  bindMultiPickerChange1: function (e) {
    var that = this;
    var length = that.data.multicitys1.length;
    var name = that.data.multicitys1;
    var air = that.data.multiair;
    var markers = [];
    var number = 0;
    that.setData({
      markers: []
    })
    for (var i = 0; i < length; i++) {
      wx.request({
        url: 'https://free-api.heweather.net/s6/air/now?',
        data: {
          location: name[i].center,
          key:'ee4d6c860dd44db187eb9193fba2227a'
        },
        success(res) {
          var mess = res.data.HeWeather6[0].status;
          if (mess != "permission denied" && mess != "unknown location")
          {
            var marker = {};
            var basic = res.data.HeWeather6[0].basic;
            var lat = (basic.lat).substring(0, 8);
            var lon = (basic.lon).substring(0, 8);
            var center = lon + "," + lat;
            var air_now_city = res.data.HeWeather6[0].air_now_city;
            if (air_now_city.qlty == air) {
              for (var j = 0; j < name.length; j++) {
                var citycenter = name[j].center;
                citycenter = citycenter.split(",");
                citycenter = citycenter[0].substring(0, 8) + "," + citycenter[1].substring(0, 8);
                if (center == citycenter) {
                  var setmarkers = "markers[" + number + "]";
                  marker.address = basic.location;
                  marker.alpha = 1;
                  marker.iconPath = "../../img/marker_red.png";
                  marker.latitude = lat;
                  marker.longitude = lon;
                  markers[number] = marker;
                  marker.title = basic.location;
                  that.setData({
                    [setmarkers]: marker
                  })
                  number++;
                }
              }
            }
          }
        },
      })
    }
  },

  bindMultiPickerColumnChange1: function (e) {
    var that = this;
    if (e.detail.column === 0) {
      var searchprovince = that.data.multiArray1[0][e.detail.value];
      wx.request({
        url: 'https://restapi.amap.com/v3/config/district?',
        data: {
          key: '0ea0022435db7b533d8cb3db5a153afa',
          keywords: searchprovince,
        },
        success(res) {
          var center = res.data.districts[0].center;
          center = center.split(",");
          var districts = res.data.districts[0].districts;
          that.setData({
            multicitys1: districts,
            multiprovince1: searchprovince,
            latitude: center[1],
            longitude: center[0]
          })
        }
      })
    }
    else if (e.detail.column === 1) {
      var air = that.data.multiArray1[1][e.detail.value];
      that.setData({
        multiair: air
      })
    }
  },

  setmultiArray1:function()
  {
    var allprovince = new province.Province();
    var that = this;
    var mul = "multiArray1[0]";
    var airq = "multiArray1[1]";
    var address = [];
    var citys = [];
    var air = ['优','良','轻度污染','中度污染','重度污染','严重污染'];
    wx.request({
      url: 'https://restapi.amap.com/v3/config/district?',
      data: {
        key: '0ea0022435db7b533d8cb3db5a153afa',
        keywords: "广东",
      },
      success(res) {
        citys = res.data.districts[0].districts;
        that.setData({
          multicitys1: citys
        })
      }
    })
    that.setData({
      [airq]:air
    })
    for (var i = 0; i < allprovince.markers.length; i++) {
      address[i] = allprovince.markers[i].address;
      this.setData({
        [mul]: address,
        scale:7
      })
    }
  },

  setmultiArray:function()
  {
    var allprovince = new province.Province();
    var that = this;
    var mul = "multiArray[0]";
    var tem = "multiArray[1]";
    var address = [];
    var temp = [];
    var citys = [];
    wx.request({
      url: 'https://restapi.amap.com/v3/config/district?',
      data: {
        key: '0ea0022435db7b533d8cb3db5a153afa',
        keywords: "广东",
      },
      success(res) {
        citys = res.data.districts[0].districts;
        that.setData({
          multicitys: citys
        })
      }
    })
    for(var j = 0; j <= 25; j++)
    {
      temp[j] = j;
      this.setData({
        [tem]:temp
      })
    }
    for(var i = 0; i < allprovince.markers.length; i++)
    {
      address[i] = allprovince.markers[i].address;
      this.setData({
        array:address,
        [mul]:address
      })
    }
  },

  bindMultiPickerColumnChange: function (e) {
    var that = this;
    if(e.detail.column === 0)
    {
      var searchprovince = that.data.multiArray[0][e.detail.value];
      wx.request({
        url: 'https://restapi.amap.com/v3/config/district?',
        data: {
          key: '0ea0022435db7b533d8cb3db5a153afa',
          keywords: searchprovince,
        },
        success(res) {
          var center = res.data.districts[0].center;
          center = center.split(",");
          var districts = res.data.districts[0].districts;
          that.setData({
            multicitys: districts,
            multiprovince:searchprovince,
            latitude:center[1],
            longitude:center[0]
          })
        }
      })
    }
    else if(e.detail.column === 1)
    {
      var temp = that.data.multiArray[1][e.detail.value];
      that.setData({
        multitem:temp
      })
    }
  },

  bindMultiPickerChange: function (e) {
    var that = this;
    var length = that.data.multicitys.length;
    var districts = that.data.multicitys;
    var tem = that.data.multitem;
    var markers = [];
    var number = 0;
    that.setData({
      markers:[]
    })
    for(var i = 0; i < length; i++)
    {
      wx.request({
        url: 'https://restapi.amap.com/v3/weather/weatherInfo?',
        data: {
          city: districts[i].adcode,
          extensions: 'base',
          key: '0ea0022435db7b533d8cb3db5a153afa'
        },
        success(res)
        {
          var marker = {};
          var lives = res.data.lives[0];
          if(lives.temperature > tem)
          {
            for(var j = 0; j < districts.length; j++)
            {
                if(lives.city == districts[j].name)
                {
                  var center = districts[j].center;
                  var setmarkers = "markers["+number+"]";
                  center = center.split(",");
                  marker.address = lives.city;
                  marker.alpha = 1;
                  marker.iconPath = "../../img/marker_red.png";
                  marker.latitude = center[1];
                  marker.longitude = center[0];
                  marker.title = lives.city + lives.temperature + "℃";
                  markers[number] = marker;
                  that.setData({
                    [setmarkers]:marker,
                    scale:7
                  })
                  number++;
                }
            }
          }
        }
      })
    }
  },

//搜索在某省温度超过res度的城市
// searchcity:function(res)
// {
//   var tem = res;
  // wx.request({
  //   url: 'https://restapi.amap.com/v3/config/district?',
  //   data:{
  //     key: '0ea0022435db7b533d8cb3db5a153afa',
  //     keywords:'广东省',
  //   },
//     success(res)
//     {
//       console.log(res);
//       var districts = res.data.districts[0].districts;
//       var number = 0;
//       for(var i = 0; i < districts.length; i++)
//       {
        // wx.request({
        //   url: 'https://restapi.amap.com/v3/weather/weatherInfo?',
        //   data:{
        //     city:districts[i].adcode,
        //     extensions:'base',
        //     key: '0ea0022435db7b533d8cb3db5a153afa'
        //   },
//           success(res) {
//             console.log(number);
//             if(res.data.lives[0].temperature > 18)
//             {
//               console.log(res.data.lives[0]);
//               console.log(districts[number]);
//             }
//             number++;
//             // console.log(number);
//             // number++;
//             // var lives = res.data.lives[0];
//             // var marker = {};
//             // console.log(districts[number]);
//             // console.log(lives.city);
//             // if(lives.temperature > 18)
//             // {
//             //   marker.address = lives.city;
//             //   marker.alpha = 1;
//             //   marker.iconPath = '../../img/marker_red.png'
//             //   marker.id = number;
//             //   console.log(districts[number]);
//             //   var center = districts[number].center;
//             //   center = center.split(",");
//             //   console.log(center);
//             //   console.log(lives.city);
//             // }
//           }
//         })
//       }
//     }
//   })
// },

//给全国各省在地图做标记点
  markerprovince:function()
  {
    var map = new province.Province();
    var markers = map.markers;
    this.setData({
      markers:markers,
      scale:4
    })
  },


  //我的位置
  getmylocation()
  {
    var that = this;
    var markers = [];
    var marker = {};
    wx.getLocation({
      success: function(res) {
        latitude = res.latitude;
        longitude = res.longitude;
      },
      success(res)
      {
        marker.alpha = 1;
        marker.iconPath="../../img/marker_red.png";
        marker.id = 0;
        marker.longitude = res.longitude;
        marker.latitude = res.latitude;
        marker.title = "我的位置";
        markers[0] = marker; 
        that.getName(res.latitude,res.longitude);
        that.setData({
          longitude:res.longitude,
          latitude:res.latitude,
          markers:markers,
          scale:14
        })
      }
    })
  },

  //根据经纬度获取城市名，省名
  getName:function(lat,lon)
  {
    var that = this;
    var city = '';
    var province = '';
      wx.request({
        url: 'https://api.map.baidu.com/reverse_geocoding/v3/?',
        data: {
          ak: 'qnYCjCB1I3MNOK9pG7zHcLESAnfHXhar',
          output: 'json',
          coordtype: 'wgs8411',
          location: lat+","+lon
        },
        success(res) {
          res = res.data.result.addressComponent;
          city = res.city;
          province = res.province;
          that.setData({
            province: province,
            city:city
          })
        }
      })
  },

  lookweather:function(e)
  {
    var sendprovince = this.data.multiprovince2;
    var sendcity = this.data.city2;
    var sendcenter = this.data.center;
    var send = [sendprovince,sendcity,sendcenter];
    wx.navigateTo({
      url: '../index2/index2',
      events: {
        // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
        acceptDataFromOpenedPage: function (data) {
          console.log(data)
        },
        someEvent: function (data) {
          console.log(data)
        }
  },
      success: function (res) {
        // 通过eventChannel向被打开页面传送数据
        res.eventChannel.emit('acceptDataFromOpenerPage',send)
      }
    })
  },

  // bindcity:function(res)
  // {
  //   var citys = [];
  //   var number = 0;
  //   var that = this;
  //   var cityname = res;
  //   let multiArray = "multiArray[1]";
  //   wx.request({
  //     url: 'https://search.heweather.net/find?',
  //     data: {
  //       location: res,
  //       key: 'ee4d6c860dd44db187eb9193fba2227a',
  //       group: 'cn',
  //       number: 20
  //     },
  //     success(res)
  //     {
  //       res = res.data.HeWeather6[0].basic;
  //       for(var i = 0; i < res.length; i++)
  //       {
  //         if(res[i].admin_area == cityname)
  //         {
  //           citys[number++] = res[i].location;
  //         }
  //       }
  //       that.setData({
  //         [multiArray]: citys
  //       })
  //     }
  //   })
  // },

  // provincesdata:function()
  // {
  //   var that = this;
  //   var number = 0;
  //   var Province = new province.Province();
  //   var length = Province.length;
  //   var provinces = [];
  //   var citys = ['新市','新和','新源','乌鲁木齐','昌吉','克拉玛依','沙依巴克','喀什','和田','石河子','阿克苏','哈密','伊犁','塔城','水磨沟','库尔勒','阿勒泰','天山','伊宁','米东'];
  //   let pro = "multiArray[0]";
  //   let city = "multiArray[1]";
  //   for(var i = 0; i < length; i++)
  //   {
  //     provinces[i] = Province.markers[i].address;
  //   }
  //   that.setData({
  //     [city]: citys,
  //     [pro]:provinces,
  //   })
  // },

  // //按空气质量显示某省城市
  // showcity_air:function()
  // {
  //   var that = this;
  //   var citys = that.data.citys;
  //   var number = that.data.number;
  //   for(var i = 0; i < number; i++)
  //   {
  //     wx.request({
  //       url: 'https://free-api.heweather.net/s6/air/now?',
  //       data:{
  //         location:citys[i].location,
  //         key:'ee4d6c860dd44db187eb9193fba2227a'
  //       },
  //       success(res)
  //       {

  //       }
  //     })
  //   }
  // },

  // //显示某个省的城市
  // showcity:function()
  // {
  //   var that = this;
  //   var markers = [];
  //   // wx.showLoading({
  //   //   title: '加载中',
  //   //   duration:1500
  //   // })
  //   for(var i = 0; i < that.data.number; i++)
  //   {
  //     var marker = {
  //       address: that.data.citys[i].location,
  //       latitude: that.data.citys[i].lat,
  //       longitude: that.data.citys[i].lon,
  //       alpha: 1,
  //       iconPath: "../../img/marker_red.png",
  //       iconTabPath: "../../img/marker_yellow.png",
  //       title:that.data.citys[i].location,
  //       id:i
  //     };
  //     // console.dir(marker.address);
  //     // console.log(marker)
  //     markers[i] = marker;
  //     // console.log(marker);
  //   }
  //   that.setData({
  //     markers:markers
  //   })
  //   // wx.hideLoading(flag);
  //   // wx.showToast({
  //   //   title: '加载成功',
  //   // })
  // },

  // //标记各省位置
  // getProvince:function()
  // {
  //   var that = this;
  //   var markers = [];
  //   var length = 0;
  //   var Province = new province.Province();
  //   markers = Province.markers;
  //   length = Province.length;
  //   that.setData({
  //     length: length,
  //     markers: markers
  //   })
  // },

  // //获取当前省份的城市
  // getProvinceCity:function()
  // {
  //   var that = this;
  //   var cityname = res[id].address;
  //   var number = 0;
  //   var citys = [];
  //   wx.request({
  //     url: 'https://search.heweather.net/find?',
  //     data:{
  //       location:cityname,
  //       key:'ee4d6c860dd44db187eb9193fba2227a',
  //       group:'cn',
  //       number:20
  //     },
  //     success(res)
  //     {
  //       //console.log(res.data.HeWeather6[0].basic);
  //       var res = res.data.HeWeather6[0].basic;
  //       for(var i = 0; i < res.length; i++)
  //       {
  //         if(res[i].admin_area == cityname )
  //         {
  //           citys[number] = res[i];
  //           number++;
  //         }
  //       }
  //       that.data.number = number;
  //       that.data.length = number;
  //     },
  //   })
  //   that.setData({
  //     citys:citys,
  //   })
  //   // that.data.citys=citys
  // },


  // //获取当前位置
  // getmylocation:function()
  // {
  //   var that = this;
  //   var marker = {};
  //   var markers = [];
  //   wx.getLocation({
  //     success: function(res) {
  //       console.log(res);
  //       latitude = res.latitude;
  //       longitude = res.longitude;
  //     },
  //     success(res)
  //     {
  //       marker.address = "广东";
  //       marker.latitude = res.latitude;
  //       marker.longitude = res.longitude;
  //       marker.alpha = 1;
  //       marker.iconPath = "../../img/marker_red.png";
  //       marker.iconTabPath = "../../img/marker_yellow.png";
  //       marker.id = 0;
  //       // marker.callout = that.data.callout,
  //       marker.title = "我的位置"
  //       markers[0] = marker;
  //       that.setData({
  //         length:1,
  //         number:1,
  //         markers:markers,
  //       })
  //     }
  //   })
  // },

  // //点击标记
  // makertap:function(e)
  // {
  //   var that = this;
  //   var id = e.markerId;
  //   that.provincemessage(that.data.markers,id);
  //   that.changeMarkerColor(that.data.markers,id);
  // },


  // //获取省份名称
  // provincemessage:function(res,id)
  // {
  //   var that = this;
  //   wx.request({
  //     url: 'http://api.map.baidu.com/reverse_geocoding/v3/?location=31.225696563611,121.49884033194',
  //     data:{
  //       ak:'qnYCjCB1I3MNOK9pG7zHcLESAnfHXhar',
  //       output:'json',
  //       coordtype:'wgs8411',
  //       location:res[id].latitude+","+res[id].longitude
  //     },
  //     success(res) {
  //       //console.log(res.data.result.addressComponent.province);
  //       res = res.data.result.addressComponent.province;
  //       that.setData({
  //         province:res
  //       })
  //     }
  //   })
  // },


  // //点击标记改变颜色
  // changeMarkerColor:function(res,id)
  // {
  //   var that = this;
  //   var markers = [];
  //   for(var j = 0; j < this.data.length; j++)
  //   {
  //     if(id == j)
  //     {
  //       res[j].iconPath = "../../img/marker_yellow.png";
  //     }
  //     else
  //     {
  //       // console.log(res[j].iconPath);
  //       res[j].iconPath = "../../img/marker_red.png";
  //     }
  //     markers[j] = res[j];
  //   }
  //   that.setData({
  //     markers:markers
  //   })
  // },


  // jump:function()
  // {
  //   wx.navigateTo({
  //     url: '../new/new',
  //     success: function(res) {},
  //     fail: function(res) {},
  //     complete: function(res) {},
  //   })
  // },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getmylocation();
    this.setmultiArray();
    this.setmultiArray1();
    this.setmultiArray2();
    // var that = this;
    // that.getmylocation();
    // that.provincesdata();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})